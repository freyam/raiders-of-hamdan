![](./assets/logo.png)

Raiders of Hamdan tells the story of the indestructible kingdom of the Hamdan. In this CLI game, you play as the Ruler of the Electra Kingdom who is trying to bring down the legacy of Hamdan.

## Gameplay

We are only able to move the great king using

1. 'w' for moving up
2. 'a' for moving towards the left
3. 's' for moving down
4. 'd' for moving towards the right

Our barbarians, are attacking the nearest building excluding walls.
This distance is the Hamiltonian distance. The king can further can use 2 spells:

1. 'h' for healing the troops and himself
2. 'r' for raging the troops and himself and for them to attack faster and better

We can also use the Shotgun, which does a lot of damage to the structures in a 1 tile radius all around him.

We have 2 powerful cannons as defensive buildings and attack the troops (barbarians and king) in a 5 tile radius.

You can watch the replay of your games to help you enhance your tactics
